# Description
The following list of ideas includes features that might or might not be introduced in the future.

If you have a feature you'd like to suggest, please open a [New Issue](https://github.com/glebtsereteli/GMRoomLoader/issues/new) with the `feature` label.

# Features

## Library
* Debug view with initialized rooms display, screenshots and customizable loading.
* `RoomLoader.load_tilemap(room, layer_name, x, y, mirror, flip, angle, xorigin, yorigin)`.
* Loading over time.
    * `RoomLoader.load_over_time()` - spread layer loading across multiple frames.
    * `RoomLoader.load_instances_overnframes()`.
    * `RoomLoader.load_instances_nperframe()`.
* Filter/Effect layers support.
* In-layer Filters/Effects support.
* Loading rooms mirrored/flipped.
* Loading rooms rotated.

## Demo
* Multiple examples with ImGui controls and info.
* Examples.
    * Procedural generation.
    * UI layouts.
    * Level selection.
    * Drag'n'drop map.
    * Endless runner.

## Docs
* Migrate to [VitePress](https://vitepress.dev/).
* Short description for biwsise flags.