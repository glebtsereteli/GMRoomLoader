> Enums are located in the `RoomLoaderEnums` script.

## `ROOMLOADER_FLAG`
The `ROOMLOADER_FLAG` enum holds bitwise flags used for filtering room elements when [loading](https://github.com/glebtsereteli/GMRoomLoader/wiki/RoomLoader()-static-constructor-%E2%80%90-main-interface#-loadroom-x-y-xorigin-yorigin-flags---structroomloaderreturndata) or [screenshotting](https://github.com/glebtsereteli/GMRoomLoader/wiki/RoomLoader()-static-constructor-%E2%80%90-main-interface#%E2%84%B9%EF%B8%8F-taking-screenshots) rooms. These can be used individually or combined together using the bitwise OR operator.

### Members
| Name  | Description |
| ------------- | ------------- |
| `NONE` | Doesn't load anything. |
| `INSTANCES` | Loads Instances from Instance layers. |
| `TILEMAPS` | Loads Tilemaps from Tile layers. |
| `SPRITES` | Loads Sprites from Asset layers. |
| `PARTICLE_SYSTEMS` | Loads Particle Systems from Asset layers. |
| `SEQUENCES` | Loads Sequences from Asset layers. |
| `BACKGROUNDS` | Loads Backgrounds from Background layers. |
| `CORE` | Includes `INSTANCES`, `SPRITES` and `TILEMAPS`. <br>Used by default via the [ROOMLOADER_DEFAULT_FLAGS](https://github.com/glebtsereteli/GMRoomLoader/wiki/Configuration#:~:text=ROOMLOADER_DEFAULT_FLAGS) config macro. |
| `EXTENDED` | Includes `PARTICLE_SYSTEMS`, `SEQUENCES` and `BACKGROUNDS`. |
| `ALL` | Includes `CORE` and `EXTENDED`. |

### Example
```js
// Loads rm_chunk_easy_01's Tilemaps:
RoomLoader.load(rm_chunk_easy_01, some_x, some_y, some_origin, ROOMLOADER_FLAG.TILEMAPS);

// Loads rm_chunk_hard_03's Instances, Sprites and Particle Systems: 
var _flags = (ROOMLOADER_FLAG.INSTANCES | ROOMLOADER_FLAG.TILEMAPS | ROOMLOADER_FLAG.PARTICLE_SYSTEMS);
RoomLoader.load(rm_chunk_hard_03, some_x, some_y, some_xorigin, some_yorigin, _flags);

// Loads rm_chunk_mid_02 with flags set to All BUT Sequences:
var _flags = (ROOMLOADER_FLAG.ALL & ~ROOMLOADER_FLAG.SEQUENCES);
RoomLoader.load(rm_chunk_mid_02, some_x, some_y, some_xorigin, some_yorigin, _flags);
```