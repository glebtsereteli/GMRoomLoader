# Getting Started
1) Download the latest .yymps package from the [Releases](https://github.com/glebtsereteli/GMRoomLoader/releases) page.
2) Import the package into your project.
   * Drag'n'drop the `GMRoomLoader vX.X.X.yymps` file into your project.
   * OR import it via **Tools/Import Local Package**.
3) Click **Add All**, then **Import**.
3) You're good to go! Check out the [Quick Setup](https://github.com/glebtsereteli/GMRoomLoader/wiki/Quick-Setup) page to load your first room and read the [Documentation](https://github.com/glebtsereteli/GMRoomLoader/wiki#documentation) below to get familiar with everything GMRoomLoader has to offer.
4) For more information, check out the [FAQ](https://github.com/glebtsereteli/GMRoomLoader/wiki/FAQ), [Upcoming Features](https://github.com/glebtsereteli/GMRoomLoader/wiki/Upcoming-Features) and [Coming from GMRoomPack (WIP)](https://github.com/glebtsereteli/GMRoomLoader/wiki/Coming-From-GMRoomPack) pages.

# Documentation
* [RoomLoader](https://github.com/glebtsereteli/GMRoomLoader/wiki/RoomLoader()-static-constructor-%E2%80%90-main-interface). Main interface, handles data and loads rooms.
* [RoomLoaderReturnData](https://github.com/glebtsereteli/GMRoomLoader/wiki/RoomLoaderReturnData()-constructor-%E2%80%90-returned-data-handler). Stores loaded elements, provides getters and handles cleanup.
* [Enums](https://github.com/glebtsereteli/GMRoomLoader/wiki/Enums). Flags.
* [Configuration](https://github.com/glebtsereteli/GMRoomLoader/wiki/Configuration). Configure various GMRoomLoader behaviors.

# Contact & Support
* Want to get some help with GMRoomLoader or share something you've made using it? Send a message in the `#gleb__gmroomloader` channel on the [GameMaker Kitchen](https://discord.gg/gamemakerkitchen) Discord server.
* Found a bug or have a feature request? Please open a [New Issue](https://github.com/glebtsereteli/GMRoomLoader/issues/new).