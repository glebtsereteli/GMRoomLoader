### 📍 How do I update to the latest version of GMRoomLoader?
1) Delete the `GMRoomLoader` folder from your project.
> [!Important]
> If you've changed any config macros in the `RoomLoaderConfig` script, make sure to copy its contents before deleting the `GMRoomLoader` folder and paste them back in after importing the new version.
> 
> Also keep in mind - the config setup might change between versions, so make sure to pay attention to the release notes.
2) Repeat points 1 and 2 from [Getting Started](https://github.com/glebtsereteli/GMRoomLoader/wiki#getting-started).
3) You're all set!

---

### 📍 Can GMRoomLoader assist with procedural generation?
No. GMRoomLoader is designed specifically for loading rooms. Procedural generation along with any custom logic for determining which room to pick and where it should go, will need to be handled on your own.

---

### 📍 How does GMRoomLoader actually "load rooms" if GameMaker can only have a single room active at a time? Does the library get around that somehow?
GameMaker can indeed only have a single room active at a time. GMRoomLoader doesn't change that. When we say "load a room", what we really mean is "recreate a room" or "load room contents". GMRoomLoader does this by taking the data from [room_get_info()](https://manual.gamemaker.io/monthly/en/GameMaker_Language/GML_Reference/Asset_Management/Rooms/room_get_info.htm), processing it for optimized loading, and using it to recreate room layers and their respective elements.

---

### 📍 I'm loading a room and it appears to work (?), but I can't see some (or all) of the loaded layers/instances. How can I fix that?
Mind your depth! GMRoomLoader creates room layers at the exact depths assigned in the Room Editor. If the room you're loading other rooms into has a few layers, make sure to manage their depths in a way to be either in front or behind loaded layers, depending on your use case.

---

### 📍 My rooms have instances with Variable Definitions and Creation Code. Does GMRoomLoader support those?
It does! [room_get_info()](https://manual.gamemaker.io/monthly/en/GameMaker_Language/GML_Reference/Asset_Management/Rooms/room_get_info.htm) provides both as scripts for GMRoomLoader to use. 
> [!Note]
>The execution order follows GameMaker's default and is structured like this:
> 1) Room-defined parameters + Variable Definitions (mixed in a single pre-create struct).
> 2) Create event.
> 3) Creation Code.

---

### 📍 Can I "destroy" or "unload" a room after loading it?
* If you're loading full rooms with [RoomLoader.load()](https://github.com/glebtsereteli/GMRoomLoader/wiki/RoomLoader()-static-constructor-%E2%80%90-main-interface#-loadroom-x-y-xorigin-yorigin-flags---structroomloaderreturndata), it returns a [RoomLoaderReturnData](https://github.com/glebtsereteli/GMRoomLoader/wiki/RoomLoaderReturnData()-constructor-%E2%80%90-returned-data-handler) instance, which includes a [.cleanup()](https://github.com/glebtsereteli/GMRoomLoader/wiki/RoomLoaderReturnData()-constructor-%E2%80%90-returned-data-handler#-cleanup---undefined) method for removing all loaded layers and their elements.
* If you're loading only instances with [RoomLoader.load_instances_layer()](https://github.com/glebtsereteli/GMRoomLoader/wiki/RoomLoader()-static-constructor-%E2%80%90-main-interface#-load_instances_layerroom-x-y-layer-xorigin-yorigin---arrayidinstance) or [RoomLoader.load_instances_depth()](https://github.com/glebtsereteli/GMRoomLoader/wiki/RoomLoader()-static-constructor-%E2%80%90-main-interface#-load_instances_depthroom-x-y-depth-xorigin-yorigin---arrayidinstance), those methods return an array of loaded instance IDs. Loop through the array and call [instance_destroy()](https://manual.gamemaker.io/monthly/en/GameMaker_Language/GML_Reference/Asset_Management/Instances/instance_destroy.htm) on each instance to remove them.
> [!Important]
> GMRoomLoader only tracks the elements it loads. Any elements you add afterwards must be cleaned up manually.







