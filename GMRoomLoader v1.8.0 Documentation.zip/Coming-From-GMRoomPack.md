# [THIS PAGE IS WIP, MORE INFO COMING SOON](https://youtu.be/hvL1339luv0?si=Hz2ozLWEMpDk4563)

# Overview
[GMRoomPack](https://yellowafterlife.itch.io/gmroompack) is a paid asset created by [YellowAfterLife](https://twitter.com/YellowAfterlife) with similar functionality. It used to be the only way to load GameMaker rooms at runtime before the introduction of [room_get_info()](https://manual.gamemaker.io/monthly/en/GameMaker_Language/GML_Reference/Asset_Management/Rooms/room_get_info.htm) in [2023.11](https://gamemaker.io/en/blog/release-2023-11#:~:text=room_get_info()%20packs%20all%20information%20about%20a%20room%20into%20a%20struct.).

# 🆚 Key Differences
| Topic  | GMRoomLoader | GMRoomPack |
| --- | --- | --- |
| Pricing  | Free ([MIT](https://en.wikipedia.org/wiki/MIT_License) license) | Paid: $4.95 on [itch](https://yellowafterlife.itch.io/gmroompack), $6.99 on [GM Marketplace](https://marketplace.gamemaker.io/assets/7525/gmroompack) |
| Setup Requirements | • In-engine [data initialization](https://github.com/glebtsereteli/GMRoomLoader/wiki/RoomLoader()-static-constructor-%E2%80%90-main-interface#-initialization)<br> • No external tools or additional steps | • [Helper CLI program](https://yal.cc/docs/gm/gmroompack/#Helper-program) to parse room .yy files and store data for future loading<br>• [Blank object](https://yal.cc/docs/gm/gmroompack/#room_pack_blank_object) to imitate instance pre-create | 
| Variable Definitions<br>Creation Code | [Native support](https://github.com/glebtsereteli/GMRoomLoader/wiki/FAQ#-my-rooms-have-instances-with-variable-definitions-and-creation-code-does-gmroomloader-support-those) | Requires an [interpreter](https://yal.cc/docs/gm/gmroompack/#room_pack_eval_script) to execute |


...

# 📜 Dictionary
...

# 📊 Loading Benchmarks
<table>
<thead>
  <tr>
    <th rowspan="2">Test</th>
    <th colspan="2">GMRoomLoader</th>
    <th colspan="2">GMRoomPack</th>
  </tr>
  <tr>
    <th>VM</th>
    <th>YYC</th>
    <th>VM</th>
    <th>YYC</th>
  </tr>
</thead>
<tbody>
  <tr>
    <td>1000 instances</td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
  </tr>
  <tr>
    <td>20x20 tilemap, 100% filled</td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
  </tr>
  <tr>
    <td>20x20 tilemap, 10% filled</td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
  </tr>
</tbody>
</table>