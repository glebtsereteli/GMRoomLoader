# Description
`RoomLoader` is GMRoomLoader's main interface. It handles data [initialization](https://github.com/glebtsereteli/GMRoomLoader/wiki/RoomLoader()-static-constructor-%E2%80%90-main-interface#-initialization) and [removal](https://github.com/glebtsereteli/GMRoomLoader/wiki/RoomLoader()-static-constructor-%E2%80%90-main-interface#-removal), [room loading](https://github.com/glebtsereteli/GMRoomLoader/wiki/RoomLoader()-static-constructor-%E2%80%90-main-interface#%E2%84%B9%EF%B8%8F-loading), [layer filtering](https://github.com/glebtsereteli/GMRoomLoader/wiki/RoomLoader()-static-constructor-%E2%80%90-main-interface#%E2%84%B9%EF%B8%8F-whitelistblacklist-layer-filtering) and [taking room screenshots](https://github.com/glebtsereteli/GMRoomLoader/wiki/RoomLoader()-static-constructor-%E2%80%90-main-interface#%E2%84%B9%EF%B8%8F-taking-screenshots).

> [!Note]
> `RoomLoader` is a namespace-like "staticon" function with static data and methods inside. It is initialized once right after declaration and does not require any additional initialization. All methods are to be called as follows: `RoomLoader.action(<arguments>)` - notice the lack of `()` after `RoomLoader`.

> `RoomLoader` is located in the `RoomLoaderMain` script.

----

# 📋 Methods

* [Data Handling](https://github.com/glebtsereteli/GMRoomLoader/wiki/RoomLoader()-static-constructor-%E2%80%90-main-interface#%E2%84%B9%EF%B8%8F-data-handling)
    * [Initialization](https://github.com/glebtsereteli/GMRoomLoader/wiki/RoomLoader()-static-constructor-%E2%80%90-main-interface#-initialization)
        * [.data_init(room, ...)](https://github.com/glebtsereteli/GMRoomLoader/wiki/RoomLoader()-static-constructor-%E2%80%90-main-interface#-data_initroom----structroomloader)
        * [.data_init_array(rooms)](https://github.com/glebtsereteli/GMRoomLoader/wiki/RoomLoader()-static-constructor-%E2%80%90-main-interface#-data_init_arrayrooms---structroomloader)
        * [.data_init_prefix(prefix)](https://github.com/glebtsereteli/GMRoomLoader/wiki/RoomLoader()-static-constructor-%E2%80%90-main-interface#-data_init_prefixprefix---arrayassetgmroom)
        * [.data_init_tag(tag)](https://github.com/glebtsereteli/GMRoomLoader/wiki/RoomLoader()-static-constructor-%E2%80%90-main-interface#-data_init_tagtag---arrayassetgmroom)
    * [Removal](https://github.com/glebtsereteli/GMRoomLoader/wiki/RoomLoader()-static-constructor-%E2%80%90-main-interface#-removal)
        * [.data_remove(room, ...)](https://github.com/glebtsereteli/GMRoomLoader/wiki/RoomLoader()-static-constructor-%E2%80%90-main-interface#-data_removeroom----structroomloader)
        * [.data_remove_array(rooms)](https://github.com/glebtsereteli/GMRoomLoader/wiki/RoomLoader()-static-constructor-%E2%80%90-main-interface#-data_remove_arrayrooms---structroomloader)
        * [.data_remove_prefix(prefix)](https://github.com/glebtsereteli/GMRoomLoader/wiki/RoomLoader()-static-constructor-%E2%80%90-main-interface#-data_remove_prefixprefix---structroomloader)
        * [.data_remove_tag(tag)](https://github.com/glebtsereteli/GMRoomLoader/wiki/RoomLoader()-static-constructor-%E2%80%90-main-interface#-data_remove_tagtag---structroomloader)
        * [.data_clear()](https://github.com/glebtsereteli/GMRoomLoader/wiki/RoomLoader()-static-constructor-%E2%80%90-main-interface#-data_clear---structroomloader)
    * [Status & Getters](https://github.com/glebtsereteli/GMRoomLoader/wiki/RoomLoader()-static-constructor-%E2%80%90-main-interface#-miscellaneous)
        * [.data_is_initialized(room)](https://github.com/glebtsereteli/GMRoomLoader/wiki/RoomLoader()-static-constructor-%E2%80%90-main-interface#-data_is_initializedroom---boolean)
        * [.data_get_width(room)](https://github.com/glebtsereteli/GMRoomLoader/wiki/RoomLoader()-static-constructor-%E2%80%90-main-interface#-data_get_widthroom---real)
        * [.data_get_height(room)](https://github.com/glebtsereteli/GMRoomLoader/wiki/RoomLoader()-static-constructor-%E2%80%90-main-interface#-data_get_heightroom---real)
* [Loading](https://github.com/glebtsereteli/GMRoomLoader/wiki/RoomLoader()-static-constructor-%E2%80%90-main-interface#%E2%84%B9%EF%B8%8F-loading)
    * [.load(room, x, y, [xorigin], [yorigin], [flags])](https://github.com/glebtsereteli/GMRoomLoader/wiki/RoomLoader()-static-constructor-%E2%80%90-main-interface#-loadroom-x-y-xorigin-yorigin-flags---structroomloaderreturndata)
    * [.load_instances_layer(room, x, y, layer, [xorigin], [yorigin])](https://github.com/glebtsereteli/GMRoomLoader/wiki/RoomLoader()-static-constructor-%E2%80%90-main-interface#-load_instances_layerroom-x-y-layer-xorigin-yorigin---arrayidinstance)
    * [.load_instances_depth(room, x, y, depth, [xorigin], [yorigin])](https://github.com/glebtsereteli/GMRoomLoader/wiki/RoomLoader()-static-constructor-%E2%80%90-main-interface#-load_instances_depthroom-x-y-depth-xorigin-yorigin---arrayidinstance)
* [Whitelist/Blacklist Layer Filtering](https://github.com/glebtsereteli/GMRoomLoader/wiki/RoomLoader()-static-constructor-%E2%80%90-main-interface#%E2%84%B9%EF%B8%8F-whitelistblacklist-layer-filtering)
    * [Whitelist](https://github.com/glebtsereteli/GMRoomLoader/wiki/RoomLoader()-static-constructor-%E2%80%90-main-interface#-whitelist)
        * [.layer_whitelist_add(layer_name, ...)](https://github.com/glebtsereteli/GMRoomLoader/wiki/RoomLoader()-static-constructor-%E2%80%90-main-interface#-layer_whitelist_addlayer_name----structroomloader)
        * [.layer_whitelist_remove(layer_name, ...)](https://github.com/glebtsereteli/GMRoomLoader/wiki/RoomLoader()-static-constructor-%E2%80%90-main-interface#-layer_whitelist_removelayer_name----structroomloader)
        * [.layer_whitelist_reset()](https://github.com/glebtsereteli/GMRoomLoader/wiki/RoomLoader()-static-constructor-%E2%80%90-main-interface#-layer_whitelist_reset---structroomloader)
        * [.layer_whitelist_get()](https://github.com/glebtsereteli/GMRoomLoader/wiki/RoomLoader()-static-constructor-%E2%80%90-main-interface#-layer_whitelist_get---arraystring)
    * [Blacklist](https://github.com/glebtsereteli/GMRoomLoader/wiki/RoomLoader()-static-constructor-%E2%80%90-main-interface#-blacklist)
        * [.layer_blacklist_add(layer_name, ...)](https://github.com/glebtsereteli/GMRoomLoader/wiki/RoomLoader()-static-constructor-%E2%80%90-main-interface#-layer_blacklist_addlayer_name----structroomloader)
        * [.layer_blacklist_remove(layer_name, ...)](https://github.com/glebtsereteli/GMRoomLoader/wiki/RoomLoader()-static-constructor-%E2%80%90-main-interface#-layer_blacklist_removelayer_name----structroomloader)
        * [.layer_blacklist_reset()](https://github.com/glebtsereteli/GMRoomLoader/wiki/RoomLoader()-static-constructor-%E2%80%90-main-interface#-layer_blacklist_reset---structroomloader)
        * [.layer_blacklist_get()](https://github.com/glebtsereteli/GMRoomLoader/wiki/RoomLoader()-static-constructor-%E2%80%90-main-interface#example-17)
* [Taking Screenshots](https://github.com/glebtsereteli/GMRoomLoader/wiki/RoomLoader()-static-constructor-%E2%80%90-main-interface#%E2%84%B9%EF%B8%8F-taking-screenshots)
    * [.take_screenshot(room, [xorigin], [yorigin], [scale], [flags])](https://github.com/glebtsereteli/GMRoomLoader/wiki/RoomLoader()-static-constructor-%E2%80%90-main-interface#-take_screenshotroom-xorigin-yorigin-scale-flags---idsprite)
    * [.take_screenshot_part(room, left, right, width, height, [xorigin], [yorigin], [scale], [flags])](https://github.com/glebtsereteli/GMRoomLoader/wiki/RoomLoader()-static-constructor-%E2%80%90-main-interface#-take_screenshot_partroom-left-top-width-height-xorigin-yorigin-scale-flags---idsprite)

---

## ℹ️ Data Handling

### 📍 Initialization
The following methods initialize room data to be used for [loading](https://github.com/glebtsereteli/GMRoomLoader/wiki/RoomLoader()-static-constructor-%E2%80%90-main-interface#%E2%84%B9%EF%B8%8F-loading) or [taking screenshots](https://github.com/glebtsereteli/GMRoomLoader/wiki/RoomLoader()-static-constructor-%E2%80%90-main-interface#-take_screenshotroom-origin-flags---idsprite-or-undefined) later.

> [!Important]
> Loading is only possible for rooms with initialized data. Make sure that data initialization is performed **before** utilizing the [loading](https://github.com/glebtsereteli/GMRoomLoader/wiki/RoomLoader()-static-constructor-%E2%80%90-main-interface#%E2%84%B9%EF%B8%8F-loading) functions.

> [!Note]
> While GMRoomLoader is designed to be as performant as possible, this part is the most performace-heavy, as it utilizes [room_get_info()](https://manual.gamemaker.io/monthly/en/GameMaker_Language/GML_Reference/Asset_Management/Rooms/room_get_info.htm) to fetch and process room data for future loading.
> It's best to call these methods _at the very start of your game_, or if you're working with large volumes and need to load/unload data throughout the game - _between levels, hidden behind a transition/loading screen_.

#### 🔶 `.data_init(room, ...)` -> [Struct](https://manual.gamemaker.io/monthly/en/GameMaker_Language/GML_Overview/Structs.htm).[RoomLoader](https://github.com/glebtsereteli/GMRoomLoader/wiki/RoomLoader()-static-constructor-%E2%80%90-main-interface)
Initializes data for all given rooms.
| Argument | Type | Description |
| ------------- | ------------- | ------------- |
| `room` | [Asset.GMRoom](https://manual.gamemaker.io/monthly/en/GameMaker_Language/GML_Reference/Asset_Management/Rooms/Rooms.htm) | The room to initialize data for. |
| `...` | [Asset.GMRoom](https://manual.gamemaker.io/monthly/en/GameMaker_Language/GML_Reference/Asset_Management/Rooms/Rooms.htm) | More rooms to initialize data for. Supports any amount of arguments. |

#### Example
```js
// Initializes data for rm_level_castle:
RoomLoader.data_init(rm_level_castle);

// Initializes data for rm_level_forest and rm_level_cliffs:
RoomLoader.data_init(rm_level_forest, rm_level_cliffs);
```

#### 🔶 `.data_init_array(rooms)` -> [Struct](https://manual.gamemaker.io/monthly/en/GameMaker_Language/GML_Overview/Structs.htm).[RoomLoader](https://github.com/glebtsereteli/GMRoomLoader/wiki/RoomLoader()-static-constructor-%E2%80%90-main-interface)
Initializes data for all rooms in the given array.
| Argument | Type | Description |
| ------------- | ------------- | ------------- |
| `rooms` | [Array](https://manual.gamemaker.io/monthly/en/GameMaker_Language/GML_Overview/Arrays.htm)<[Asset.GMRoom](https://manual.gamemaker.io/monthly/en/GameMaker_Language/GML_Reference/Asset_Management/Rooms/Rooms.htm)>  | The array of rooms to initialize data for. |

#### Example
```js
// Initializes data for all rooms inside the rooms array:
rooms = [rm_level_cabin, rm_level_alley, rm_level_beach];
RoomLoader.data_init_array(rooms);
```

#### 🔶 `.data_init_prefix(prefix)` -> [Array](https://manual.gamemaker.io/monthly/en/GameMaker_Language/GML_Overview/Arrays.htm)<[Asset.GMRoom](https://manual.gamemaker.io/monthly/en/GameMaker_Language/GML_Reference/Asset_Management/Rooms/Rooms.htm)>
Initializes data for all rooms starting with the given prefix. Returns an array of found rooms.
| Argument | Type | Description |
| ------------- | ------------- | ------------- |
| `prefix` | [String](https://manual.gamemaker.io/monthly/en/GameMaker_Language/GML_Reference/Strings/Strings.htm)  | The prefix to filter rooms with. |

#### Example
```js
// Initializes data for all rooms starting with "rm_level_" and stores found rooms in a variable:
rooms = RoomLoader.data_init_prefix("rm_level_");
```

#### 🔶 `.data_init_tag(tag)` -> [Array](https://manual.gamemaker.io/monthly/en/GameMaker_Language/GML_Overview/Arrays.htm)<[Asset.GMRoom](https://manual.gamemaker.io/monthly/en/GameMaker_Language/GML_Reference/Asset_Management/Rooms/Rooms.htm)>
Initializes data for all rooms with the given tag assigned. Returns an array of found rooms.
| Argument | Type | Description |
| ------------- | ------------- | ------------- |
| `tag` | [String](https://manual.gamemaker.io/monthly/en/GameMaker_Language/GML_Reference/Strings/Strings.htm)  | The tag to extract rooms from. |

#### Example
```js
// Initializes data for all rooms with the "rooms_dungeon" tag assigned and stores found rooms in a variable:
rooms = RoomLoader.data_init_tag("rooms_dungeon");
```

---

### 📍 Removal
Even though the initialized room data doesn't take _too much_ space, you still might want to unload it for rooms that are no longer needed. The following methods follow the [Initialization](https://github.com/glebtsereteli/GMRoomLoader/wiki/RoomLoader()-static-constructor-%E2%80%90-main-interface#-initialization) structure and remove initialized room data from [RoomLoader](https://github.com/glebtsereteli/GMRoomLoader/wiki/RoomLoader()-static-constructor-%E2%80%90-main-interface)'s internal data pool.

#### 🔶 `.data_remove(room, ...)` -> [Struct](https://manual.gamemaker.io/monthly/en/GameMaker_Language/GML_Overview/Structs.htm).[RoomLoader](https://github.com/glebtsereteli/GMRoomLoader/wiki/RoomLoader()-static-constructor-%E2%80%90-main-interface)
Removes data for all (initialized) given rooms.
| Argument | Type | Description |
| ------------- | ------------- | ------------- |
| `room` | [Asset.GMRoom](https://manual.gamemaker.io/monthly/en/GameMaker_Language/GML_Reference/Asset_Management/Rooms/Rooms.htm) | The room to remove data for. |
| `...` | [Asset.GMRoom](https://manual.gamemaker.io/monthly/en/GameMaker_Language/GML_Reference/Asset_Management/Rooms/Rooms.htm) | More rooms to remove data for. Supports any amount of arguments. |

#### Example
```js
// Removes data for rm_level_castle:
RoomLoader.data_remove(rm_level_castle);

// Removes data for rm_level_forest and rm_level_cliffs:
RoomLoader.data_remove(rm_level_forest, rm_level_cliffs);
```

#### 🔶 `.data_remove_array(rooms)` -> [Struct](https://manual.gamemaker.io/monthly/en/GameMaker_Language/GML_Overview/Structs.htm).[RoomLoader](https://github.com/glebtsereteli/GMRoomLoader/wiki/RoomLoader()-static-constructor-%E2%80%90-main-interface)
Removes data for all (initialized) rooms in the given array.
| Argument | Type | Description |
| ------------- | ------------- | ------------- |
| `rooms` | [Array](https://manual.gamemaker.io/monthly/en/GameMaker_Language/GML_Overview/Arrays.htm)<[Asset.GMRoom](https://manual.gamemaker.io/monthly/en/GameMaker_Language/GML_Reference/Asset_Management/Rooms/Rooms.htm)>  | The array of rooms to remove data for. |

#### Example
```js
// Removes data for all rooms inside the rooms array:
rooms = [rm_level_cabin, rm_level_alley, rm_level_beach];
RoomLoader.data_remove_array(rooms);
```

#### 🔶 `.data_remove_prefix(prefix)` -> [Struct](https://manual.gamemaker.io/monthly/en/GameMaker_Language/GML_Overview/Structs.htm).[RoomLoader](https://github.com/glebtsereteli/GMRoomLoader/wiki/RoomLoader()-static-constructor-%E2%80%90-main-interface)
Removes data for all (initialized) rooms starting with the given prefix.
| Argument | Type | Description |
| ------------- | ------------- | ------------- |
| `prefix` | [String](https://manual.gamemaker.io/monthly/en/GameMaker_Language/GML_Reference/Strings/Strings.htm)  | The prefix to filter rooms with. |

#### Example
```js
// Removes data for all rooms starting with "rm_level_":
RoomLoader.data_remove_prefix("rm_level_");
```

#### 🔶 `.data_remove_tag(tag)` -> [Struct](https://manual.gamemaker.io/monthly/en/GameMaker_Language/GML_Overview/Structs.htm).[RoomLoader](https://github.com/glebtsereteli/GMRoomLoader/wiki/RoomLoader()-static-constructor-%E2%80%90-main-interface)
Removes data for all rooms with the given tag assigned.
| Argument | Type | Description |
| ------------- | ------------- | ------------- |
| `tag` | [String](https://manual.gamemaker.io/monthly/en/GameMaker_Language/GML_Reference/Strings/Strings.htm)  | TThe tag to extract rooms from. |

#### Example
```js
// Removes data for all rooms with the "rooms_forest" assigned:
RoomLoader.data_remove_prefix("rooms_forest");
```

#### 🔶 `.data_clear()` -> [Struct](https://manual.gamemaker.io/monthly/en/GameMaker_Language/GML_Overview/Structs.htm).[RoomLoader](https://github.com/glebtsereteli/GMRoomLoader/wiki/RoomLoader()-static-constructor-%E2%80%90-main-interface)
Removes all initialized room data.

#### Example
```js
// Clears all previously initialized room data:
RoomLoader.data_clear();
```

---

### 📍 Status & Getters

#### 🔶 `.data_is_initialized(room)` -> [Boolean](https://manual.gamemaker.io/monthly/en/GameMaker_Language/GML_Overview/Data_Types.htm#:~:text=Real%20Numbers-,Boolean,-Strings)
Checks whether the data for the given room is initialized (returns `true`) or not (return `false`).
| Argument | Type | Description |
| ------------- | ------------- | ------------- |
| `room` | [Asset.GMRoom](https://manual.gamemaker.io/monthly/en/GameMaker_Language/GML_Reference/Asset_Management/Rooms/Rooms.htm) | The room to check. |

#### Example
```js
if (RoomLoader.data_is_initialized(rm_level_tower)) {
    // Yay, the data for rm_level_tower is initialized!
}
```

#### 🔶 `.data_get_width(room)` -> [Real](https://manual.gamemaker.io/monthly/en/GameMaker_Language/GML_Overview/Data_Types.htm#:~:text=of%20the%20following%3A-,Real%20Numbers,-Boolean)
Returns the width of the given room.
| Argument | Type | Description |
| ------------- | ------------- | ------------- |
| `room` | [Asset.GMRoom](https://manual.gamemaker.io/monthly/en/GameMaker_Language/GML_Reference/Asset_Management/Rooms/Rooms.htm) | The room to get the width for. |

#### Example
```js
var _width = RoomLoader.data_get_width(rm_level_dungeon);
```

#### 🔶 `.data_get_height(room)` -> [Real](https://manual.gamemaker.io/monthly/en/GameMaker_Language/GML_Overview/Data_Types.htm#:~:text=of%20the%20following%3A-,Real%20Numbers,-Boolean)
Returns the height of the given room.
| Argument | Type | Description |
| ------------- | ------------- | ------------- |
| `room` | [Asset.GMRoom](https://manual.gamemaker.io/monthly/en/GameMaker_Language/GML_Reference/Asset_Management/Rooms/Rooms.htm) | The room to get the height for. |

#### Example
```js
var _height = RoomLoader.data_get_height(rm_level_dungeon);
```

---

## ℹ️ Loading
The following methods handle room loading.

> [!Important]
> Loading is only possible for rooms with initialized data. Make sure that data [initialization](https://github.com/glebtsereteli/GMRoomLoader/wiki/RoomLoader()-static-constructor-%E2%80%90-main-interface#-initialization) is performed **before** utilizing the following functions.

#### 🔶 `.load(room, x, y, [xorigin], [yorigin], [flags])` -> [Struct](https://manual.gamemaker.io/monthly/en/GameMaker_Language/GML_Overview/Structs.htm).[RoomLoaderReturnData](https://github.com/glebtsereteli/GMRoomLoader/wiki/RoomLoaderReturnData()-constructor-%E2%80%90-returned-data-handler)
Loads the given room at the given coordinates, [xorigin] and [yorigin], filtered by the given [flags]. Returns an instance of the [RoomLoaderReturnData](https://github.com/glebtsereteli/GMRoomLoader/wiki/RoomLoaderReturnData()-constructor-%E2%80%90-returned-data-handler) constructor.

| Argument | Type | Description |
| --- | --- | --- |
| `room` | [Asset.GMRoom](https://manual.gamemaker.io/monthly/en/GameMaker_Language/GML_Reference/Asset_Management/Rooms/Rooms.htm) | The room to load. |
| `x` | [Real](https://manual.gamemaker.io/monthly/en/GameMaker_Language/GML_Overview/Data_Types.htm#:~:text=of%20the%20following%3A-,Real%20Numbers,-Boolean)  | The X coordinate to load the room at. |
| `y` | [Real](https://manual.gamemaker.io/monthly/en/GameMaker_Language/GML_Overview/Data_Types.htm#:~:text=of%20the%20following%3A-,Real%20Numbers,-Boolean)  | The Y coordinate to load the room at. |
| `[xorigin=ROOMLOADER_DEFAULT_XORIGIN]` | [Real](https://manual.gamemaker.io/monthly/en/GameMaker_Language/GML_Overview/Data_Types.htm#:~:text=of%20the%20following%3A-,Real%20Numbers,-Boolean) | The x origin to load the room at. <br>**[Optional].** Defaults to the [ROOMLOADER_DEFAULT_XORIGIN](https://github.com/glebtsereteli/GMRoomLoader/wiki/Configuration#:~:text=ROOMLOADER_DEFAULT_XORIGIN) config macro.
| `[yorigin=ROOMLOADER_DEFAULT_YORIGIN]` | [Real](https://manual.gamemaker.io/monthly/en/GameMaker_Language/GML_Overview/Data_Types.htm#:~:text=of%20the%20following%3A-,Real%20Numbers,-Boolean) | The y origin to load the room at. <br>**[Optional].** Defaults to the [ROOMLOADER_DEFAULT_YORIGIN](https://github.com/glebtsereteli/GMRoomLoader/wiki/Configuration#:~:text=ROOMLOADER_DEFAULT_YORIGIN) config macro.
| `[flags=ROOMLOADER_DEFAULT_FLAGS]` | [Enum](https://manual.gamemaker.io/monthly/en/GameMaker_Language/GML_Overview/Variables/Constants.htm#:~:text=get%20an%20error.-,Enums,-An%20enum%20is).[ROOMLOADER_FLAG](https://github.com/glebtsereteli/GMRoomLoader/wiki/Enums#roomloader_flag) | The flags to filter the loaded data by. <br>**[Optional].** Defaults to the [ROOMLOADER_DEFAULT_FLAGS](https://github.com/glebtsereteli/GMRoomLoader/wiki/Configuration#:~:text=ROOMLOADER_DEFAULT_FLAGS) config macro.
#### Example
```js
// Loads rm_level_castle at arbitrary coordinates:
RoomLoader.load(rm_level_castle, some_x, some_y);

// Loads rm_level_forest centered in the room: 
var _x = (room_width / 2);
var _y = (room_height / 2);
RoomLoader.load(rm_level_forest, _x, _y, 0.5, 0.5);

// Loads rm_level_cliffs's Sprites and Tilemaps at the bottom-right corner of the room
// and stores the returned instance of RoomLoaderReturnData in a variable to be cleaned up later:
var _flags = (ROOMLOADER_FLAG.SPRITES | ROOMLOADER_FLAG.TILEMAPS);
data = RoomLoader.load(rm_level_cliffs, room_width, room_height, 1, 1, _flags);
```

> [!Note]
> The table below outlines the currently supported room contents.
> | Contents | Layer Type | Implemented | Planned| 
> | --- | --- | --- | --- |
> | Instances | Instance | ✔️ | ✔️ | 
> | Tilemaps | Tile | ✔️ | ✔️ | 
> | Sprites | Asset | ✔️ | ✔️ | 
> | Particle Systems | Asset | 🚧 | ✔️ | 
> | Sequences | Asset | ✔️ | ✔️ | 
> | Backgrounds | Background | ✔️ | ✔️ | 
> | Filters/Effects | Filter/Effect | ❌ | ✔️ | 
> | In-layer Filters/Effects | Any | ❌ | ✔️ |
> | Creation Code | - | ✔️ | ✔️ | 
> | Views | - | ❌ | ❌ | 
> | Physics | - | ❌ | ❌ | 
> | Display Buffer & Viewport Clearing | - | ❌ | ❌ |

#### 🔶 `.load_instances_layer(room, x, y, layer, [xorigin], [yorigin])` -> [Array](https://manual.gamemaker.io/monthly/en/GameMaker_Language/GML_Overview/Arrays.htm)<[Id.Instance](https://manual.gamemaker.io/monthly/en/GameMaker_Language/GML_Reference/Asset_Management/Instances/Instances.htm)>
Loads the given room's instances at the given coordinates, layer, [xorigin] and [yorigin]. Returns an array of created Instance IDs.
| Argument | Type | Description |
| ------------- | ------------- | ------------- |
| `room` | [Asset.GMRoom](https://manual.gamemaker.io/monthly/en/GameMaker_Language/GML_Reference/Asset_Management/Rooms/Rooms.htm) | The room to load instances for. |
| `x` | [Real](https://manual.gamemaker.io/monthly/en/GameMaker_Language/GML_Overview/Data_Types.htm#:~:text=of%20the%20following%3A-,Real%20Numbers,-Boolean)  | The X coordinate to load instances at. |
| `y` | [Real](https://manual.gamemaker.io/monthly/en/GameMaker_Language/GML_Overview/Data_Types.htm#:~:text=of%20the%20following%3A-,Real%20Numbers,-Boolean)  | The Y coordinate to load instances at. |
| `layer` | [Id.Layer](https://manual.gamemaker.io/monthly/en/GameMaker_Language/GML_Reference/Asset_Management/Rooms/General_Layer_Functions/layer_get_id.htm) or [String](https://manual.gamemaker.io/monthly/en/GameMaker_Language/GML_Reference/Strings/Strings.htm) | The Layer ID (or name) to assign intances to. |
| `[xorigin=ROOMLOADER_DEFAULT_XORIGIN]` | [Real](https://manual.gamemaker.io/monthly/en/GameMaker_Language/GML_Overview/Data_Types.htm#:~:text=of%20the%20following%3A-,Real%20Numbers,-Boolean) | The x origin to load the room at. <br>**[Optional].** Defaults to the [ROOMLOADER_DEFAULT_XORIGIN](https://github.com/glebtsereteli/GMRoomLoader/wiki/Configuration#:~:text=ROOMLOADER_DEFAULT_XORIGIN) config macro.
| `[yorigin=ROOMLOADER_DEFAULT_YORIGIN]` | [Real](https://manual.gamemaker.io/monthly/en/GameMaker_Language/GML_Overview/Data_Types.htm#:~:text=of%20the%20following%3A-,Real%20Numbers,-Boolean) | The y origin to load the room at. <br>**[Optional].** Defaults to the [ROOMLOADER_DEFAULT_YORIGIN](https://github.com/glebtsereteli/GMRoomLoader/wiki/Configuration#:~:text=ROOMLOADER_DEFAULT_YORIGIN) config macro.

#### Example
```js
// Loads rm_level_castle's instances at arbitrary coordinates on the "Instances" layer:
var _layer = layer_get_id("Instances");
RoomLoader.load_instances_layer(rm_level_castle, some_x, some_y, _layer);

// Loads rm_level_castle's instances at the bottom-left corner of the room on the "Instances" layer
// and stores the returned array of instance IDs in a variable:
instances = RoomLoader.load_instances_layer(rm_level_castle, 0, room_height, "Instances", 0, 1);
```

#### 🔶 `.load_instances_depth(room, x, y, depth, [xorigin], [yorigin])` -> [Array](https://manual.gamemaker.io/monthly/en/GameMaker_Language/GML_Overview/Arrays.htm)<[Id.Instance](https://manual.gamemaker.io/monthly/en/GameMaker_Language/GML_Reference/Asset_Management/Instances/Instances.htm)>
Loads the given room's instances at the given coordinates, depth, [xorigin] and [yorigin]. Returns an array of created Instance IDs.
| Argument | Type | Description |
| ------------- | ------------- | ------------- |
| `room` | [Asset.GMRoom](https://manual.gamemaker.io/monthly/en/GameMaker_Language/GML_Reference/Asset_Management/Rooms/Rooms.htm) | The room to load instances for. |
| `x` | [Real](https://manual.gamemaker.io/monthly/en/GameMaker_Language/GML_Overview/Data_Types.htm#:~:text=of%20the%20following%3A-,Real%20Numbers,-Boolean)  | The X coordinate to load instances at. |
| `y` | [Real](https://manual.gamemaker.io/monthly/en/GameMaker_Language/GML_Overview/Data_Types.htm#:~:text=of%20the%20following%3A-,Real%20Numbers,-Boolean)  | The Y coordinate to load instances at. |
| `depth` | [Real](https://manual.gamemaker.io/monthly/en/GameMaker_Language/GML_Overview/Data_Types.htm#:~:text=of%20the%20following%3A-,Real%20Numbers,-Boolean) | The depth to create instances at. |
| `[xorigin=ROOMLOADER_DEFAULT_XORIGIN]` | [Real](https://manual.gamemaker.io/monthly/en/GameMaker_Language/GML_Overview/Data_Types.htm#:~:text=of%20the%20following%3A-,Real%20Numbers,-Boolean) | The x origin to load the room at. <br>**[Optional].** Defaults to the [ROOMLOADER_DEFAULT_XORIGIN](https://github.com/glebtsereteli/GMRoomLoader/wiki/Configuration#:~:text=ROOMLOADER_DEFAULT_XORIGIN) config macro.
| `[yorigin=ROOMLOADER_DEFAULT_YORIGIN]` | [Real](https://manual.gamemaker.io/monthly/en/GameMaker_Language/GML_Overview/Data_Types.htm#:~:text=of%20the%20following%3A-,Real%20Numbers,-Boolean) | The y origin to load the room at. <br>**[Optional].** Defaults to the [ROOMLOADER_DEFAULT_YORIGIN](https://github.com/glebtsereteli/GMRoomLoader/wiki/Configuration#:~:text=ROOMLOADER_DEFAULT_YORIGIN) config macro.

#### Example
```js
// Loads rm_level_castle's instances at arbitrary coordinates and -1000 depth:
RoomLoader.load_instances_depth(rm_level_castle, some_x, some_y, -1000);

// Loads rm_level_castle's instances at the top-right corner of the room at depth 250
// and stores the returned array of instance IDs in a variable:
instances = RoomLoader.load_instances_depth(rm_level_castle, room_width, 0, 250, 1, 0);
```

---

## ℹ️ Whitelist/Blacklist Layer Filtering
In addition to [bitwise flag filtering](https://github.com/glebtsereteli/GMRoomLoader/wiki/Enums#roomloader_flag), GMRoomLoader supports layer-based filtering via whitelisting/blacklisting.
* Whitelisting will only load the layers with specified names.
* Blacklisting excludes the layers with specified names from loading.
* Both filters have their own sets of methods and can be active either on their own or together. For example:
```js
RoomLoader
.layer_whitelist_add("trees", "rocks", "grass") // Whitelists "trees", "rocks" and "grass" layer names. Only these layers will be loaded.
.layer_blacklist_add("rocks") // Blacklists the "rocks" layer name. Only "trees" and "grass" layers will be loaded.
.load(...); // Load...
```
> [!Note]
> * Filtering applies to [.load()](https://github.com/glebtsereteli/GMRoomLoader/wiki/RoomLoader()-static-constructor-%E2%80%90-main-interface#-loadroom-x-y-xorigin-yorigin-flags---structroomloaderreturndata) and [.take_screenshot()](https://github.com/glebtsereteli/GMRoomLoader/wiki/RoomLoader()-static-constructor-%E2%80%90-main-interface#-take_screenshotroom-xorigin-yorigin-scale-flags---idsprite) methods.
> * Filters are managed entirely by the user and are not reset automatically after loading.
> * The following methods should be called prior to [.load()](https://github.com/glebtsereteli/GMRoomLoader/wiki/RoomLoader()-static-constructor-%E2%80%90-main-interface#-loadroom-x-y-xorigin-yorigin-flags---structroomloaderreturndata)/[.take_screenshot()](https://github.com/glebtsereteli/GMRoomLoader/wiki/RoomLoader()-static-constructor-%E2%80%90-main-interface#-take_screenshotroom-xorigin-yorigin-scale-flags---idsprite) for them to take effect.

### 📍 Whitelist
#### 🔶 `.layer_whitelist_add(layer_name, ...)` -> [Struct](https://manual.gamemaker.io/monthly/en/GameMaker_Language/GML_Overview/Structs.htm).[RoomLoader](https://github.com/glebtsereteli/GMRoomLoader/wiki/RoomLoader()-static-constructor-%E2%80%90-main-interface)
Adds all given layer names to the Whitelist filter.
| Argument | Type | Description |
| ------------- | ------------- | ------------- |
| `layer_name` | [String](https://manual.gamemaker.io/monthly/en/GameMaker_Language/GML_Reference/Strings/Strings.htm) | The layer name to whitelist. |
| `...` | [String](https://manual.gamemaker.io/monthly/en/GameMaker_Language/GML_Reference/Strings/Strings.htm) | More layer names. Supports any amount of arguments. |

#### Example
```js
// Whitelists the "buildings" layer name:
RoomLoader.layer_whitelist_add("buildings");

// Whitelists the "trees" and "rocks" layer names:
RoomLoader.layer_whitelist_add("trees", "rocks");
```

#### 🔶 `.layer_whitelist_remove(layer_name, ...)` -> [Struct](https://manual.gamemaker.io/monthly/en/GameMaker_Language/GML_Overview/Structs.htm).[RoomLoader](https://github.com/glebtsereteli/GMRoomLoader/wiki/RoomLoader()-static-constructor-%E2%80%90-main-interface)
Removes all given layer names from the Whitelist filter.
| Argument | Type | Description |
| ------------- | ------------- | ------------- |
| `layer_name` | [String](https://manual.gamemaker.io/monthly/en/GameMaker_Language/GML_Reference/Strings/Strings.htm) | The layer name to whitelist. |
| `...` | [String](https://manual.gamemaker.io/monthly/en/GameMaker_Language/GML_Reference/Strings/Strings.htm) | More layer names. Supports any amount of arguments. |

#### Example
```js
// Removes the "buildings" layer name from Whitelist:
RoomLoader.layer_whitelist_remove("buildings");

// Removes "trees" and "rocks" layer names from Whitelist:
RoomLoader.layer_whitelist_remove("trees", "rocks");
```

#### 🔶 `.layer_whitelist_reset()` -> [Struct](https://manual.gamemaker.io/monthly/en/GameMaker_Language/GML_Overview/Structs.htm).[RoomLoader](https://github.com/glebtsereteli/GMRoomLoader/wiki/RoomLoader()-static-constructor-%E2%80%90-main-interface)
Resets the Whitelist by removing previously set layer names.

#### Example
```js
// Resets the Whitelist:
RoomLoader.layer_whitelist_reset();
```

#### 🔶 `.layer_whitelist_get()` -> [Array](https://manual.gamemaker.io/monthly/en/GameMaker_Language/GML_Overview/Arrays.htm)<[String](https://manual.gamemaker.io/monthly/en/GameMaker_Language/GML_Reference/Strings/Strings.htm)>
Returns an array of whitelisted layer names.

#### Example
```js
// Gets an array of whitelisted layer names, blacklists them and resets Whitelist:
array_foreach(RoomLoader.layer_whitelist_get(), function(_layer_name) {
    RoomLoader.layer_blacklist_add(_layer_name);
});
RoomLoader.layer_whitelist_reset();
```

---

### 📍 Blacklist

#### 🔶 `.layer_blacklist_add(layer_name, ...)` -> [Struct](https://manual.gamemaker.io/monthly/en/GameMaker_Language/GML_Overview/Structs.htm).[RoomLoader](https://github.com/glebtsereteli/GMRoomLoader/wiki/RoomLoader()-static-constructor-%E2%80%90-main-interface)
Adds all given layer names to the Blacklist filter.
| Argument | Type | Description |
| ------------- | ------------- | ------------- |
| `layer_name` | [String](https://manual.gamemaker.io/monthly/en/GameMaker_Language/GML_Reference/Strings/Strings.htm) | The layer name to blacklist. |
| `...` | [String](https://manual.gamemaker.io/monthly/en/GameMaker_Language/GML_Reference/Strings/Strings.htm) | More layer names. Supports any amount of arguments. |

#### Example
```js
// Blacklists the "buildings" layer name:
RoomLoader.layer_blacklist_add("buildings");

// Blacklists the "trees" and "rocks" layer names:
RoomLoader.layer_blacklist_add("trees", "rocks");
```

#### 🔶 `.layer_blacklist_remove(layer_name, ...)` -> [Struct](https://manual.gamemaker.io/monthly/en/GameMaker_Language/GML_Overview/Structs.htm).[RoomLoader](https://github.com/glebtsereteli/GMRoomLoader/wiki/RoomLoader()-static-constructor-%E2%80%90-main-interface)
Removes all given layer names from the Blacklist filter.
| Argument | Type | Description |
| ------------- | ------------- | ------------- |
| `layer_name` | [String](https://manual.gamemaker.io/monthly/en/GameMaker_Language/GML_Reference/Strings/Strings.htm) | The layer name to blacklist. |
| `...` | [String](https://manual.gamemaker.io/monthly/en/GameMaker_Language/GML_Reference/Strings/Strings.htm) | More layer names. Supports any amount of arguments. |

#### Example
```js
// Removes the "buildings" layer name from Blacklist:
RoomLoader.layer_blacklist_remove("buildings");

// Removes "trees" and "rocks" layer names from Blacklist:
RoomLoader.layer_blacklist_remove("trees", "rocks");
```

#### 🔶 `.layer_blacklist_reset()` -> [Struct](https://manual.gamemaker.io/monthly/en/GameMaker_Language/GML_Overview/Structs.htm).[RoomLoader](https://github.com/glebtsereteli/GMRoomLoader/wiki/RoomLoader()-static-constructor-%E2%80%90-main-interface)
Resets the Blacklist by removing all previously added layer names.

#### Example
```js
// Resets the Blacklist:
RoomLoader.layer_blacklist_reset();
```

#### 🔶 `.layer_blacklist_get()` -> [Array](https://manual.gamemaker.io/monthly/en/GameMaker_Language/GML_Overview/Arrays.htm)<[String](https://manual.gamemaker.io/monthly/en/GameMaker_Language/GML_Reference/Strings/Strings.htm)>
Returns an array of blacklisted layer names.

#### Example
```js
// Gets an array of blacklisted layer names, whitelists them and resets Blacklist:
array_foreach(RoomLoader.layer_blacklist_get(), function(_layer_name) {
    RoomLoader.layer_whitelist_add(_layer_name);
});
RoomLoader.layer_blacklist_reset();
```

## ℹ️ Taking Screenshots

> [!Important]
> The following methods return new sprite created by [sprite_create_from_surface()](https://manual.gamemaker.io/monthly/en/GameMaker_Language/GML_Reference/Asset_Management/Sprites/Sprite_Manipulation/sprite_create_from_surface.htm).
> Make sure to keep track of them and delete them using [sprite_delete()](https://manual.gamemaker.io/monthly/en/GameMaker_Language/GML_Reference/Asset_Management/Sprites/Sprite_Manipulation/sprite_delete.htm) when they're no longer needed.

#### 🔶 `.take_screenshot(room, [xorigin], [yorigin], [scale], [flags])` -> [Id.Sprite](https://manual.gamemaker.io/monthly/en/GameMaker_Language/GML_Reference/Asset_Management/Sprites/Sprite_Manipulation/sprite_create_from_surface.htm)
Takes a screenshot of the given room. Assigns the given origin and scale to the created sprite and filters the captured elements by the given flags.
Returns a Sprite ID.

| Argument | Type | Description |
| ------------- | ------------- | ------------- |
| `room` | [Asset.GMRoom](https://manual.gamemaker.io/monthly/en/GameMaker_Language/GML_Reference/Asset_Management/Rooms/Rooms.htm) | The room to take a screenshot of. |
| `[xorigin=ROOMLOADER_DEFAULT_XORIGIN]` | [Real](https://manual.gamemaker.io/monthly/en/GameMaker_Language/GML_Overview/Data_Types.htm#:~:text=of%20the%20following%3A-,Real%20Numbers,-Boolean) | The x origin to load the room at. <br>**[Optional].** Defaults to the [ROOMLOADER_DEFAULT_XORIGIN](https://github.com/glebtsereteli/GMRoomLoader/wiki/Configuration#:~:text=ROOMLOADER_DEFAULT_XORIGIN) config macro.
| `[yorigin=ROOMLOADER_DEFAULT_YORIGIN]` | [Real](https://manual.gamemaker.io/monthly/en/GameMaker_Language/GML_Overview/Data_Types.htm#:~:text=of%20the%20following%3A-,Real%20Numbers,-Boolean) | The y origin to load the room at. <br>**[Optional].** Defaults to the [ROOMLOADER_DEFAULT_YORIGIN](https://github.com/glebtsereteli/GMRoomLoader/wiki/Configuration#:~:text=ROOMLOADER_DEFAULT_YORIGIN) config macro.
| `[scale=1]` | [Real](https://manual.gamemaker.io/monthly/en/GameMaker_Language/GML_Overview/Data_Types.htm#:~:text=of%20the%20following%3A-,Real%20Numbers,-Boolean) | The scale to create the sprite at. <br>**[Optional].** Defaults to 1. |
| `[flags=ROOMLOADER_FLAG.ALL]` | [Enum](https://manual.gamemaker.io/monthly/en/GameMaker_Language/GML_Overview/Variables/Constants.htm#:~:text=get%20an%20error.-,Enums,-An%20enum%20is).[ROOMLOADER_FLAG](https://github.com/glebtsereteli/GMRoomLoader/wiki/Enums#roomloader_flag) | The flags to filter the captured elements by. <br>**[Optional].** Defaults to the [ROOMLOADER_FLAG.ALL](https://github.com/glebtsereteli/GMRoomLoader/wiki/Enums#:~:text=and%20BACKGROUNDS.-,ALL,-Includes%20CORE%20and) flags.
#### Example
```js
// Create event. Take a screenshot of the rm_chunk_easy_01 room with a Middle Center origin,
// only capture Tilemaps and Sprites:
var _flags = (ROOMLOADER_FLAG.TILEMAPS | ROOMLOADER_FLAG.SPRITES);
screenshot = RoomLoader.take_screenshot(rm_chunk_easy_01, 0.5, 0.5, _flags);

// Draw GUI event. Draw screenshot centered on the screen:
if (screenshot != undefined) {
    var _x = display_get_gui_width() / 2;
    var _y = display_get_gui_height() / 2;
    draw_sprite(screenshot, 0, _x, _y);
}
```

#### 🔶 `.take_screenshot_part(room, left, top, width, height, [xorigin], [yorigin], [scale], [flags])` -> [Id.Sprite](https://manual.gamemaker.io/monthly/en/GameMaker_Language/GML_Reference/Asset_Management/Sprites/Sprite_Manipulation/sprite_create_from_surface.htm)
Takes a screenshot of the given room. Assigns the given origin and scale to the created sprite and filters the captured elements by the given flags.
Returns a Sprite ID.

| Argument | Type | Description |
| ------------- | ------------- | ------------- |
| `room` | [Asset.GMRoom](https://manual.gamemaker.io/monthly/en/GameMaker_Language/GML_Reference/Asset_Management/Rooms/Rooms.htm) | The room to take a screenshot of. |
| `left` | [Real](https://manual.gamemaker.io/monthly/en/GameMaker_Language/GML_Overview/Data_Types.htm#:~:text=of%20the%20following%3A-,Real%20Numbers,-Boolean) | The x position on the sprite of the top left corner of the area to capture, as a 0-1 percentage. |
| `top` | [Real](https://manual.gamemaker.io/monthly/en/GameMaker_Language/GML_Overview/Data_Types.htm#:~:text=of%20the%20following%3A-,Real%20Numbers,-Boolean) | The y position on the sprite of the top left corner of the area to capture, as a 0-1 percentage. |
| `width` | [Real](https://manual.gamemaker.io/monthly/en/GameMaker_Language/GML_Overview/Data_Types.htm#:~:text=of%20the%20following%3A-,Real%20Numbers,-Boolean) | The width of the area to capture, as a 0-1 percentage. |
| `height` | [Real](https://manual.gamemaker.io/monthly/en/GameMaker_Language/GML_Overview/Data_Types.htm#:~:text=of%20the%20following%3A-,Real%20Numbers,-Boolean) | The height of the area to capture, as a 0-1 percentage. |
| `[xorigin=ROOMLOADER_DEFAULT_XORIGIN]` | [Real](https://manual.gamemaker.io/monthly/en/GameMaker_Language/GML_Overview/Data_Types.htm#:~:text=of%20the%20following%3A-,Real%20Numbers,-Boolean) | The x origin to load the room at. <br>**[Optional].** Defaults to the [ROOMLOADER_DEFAULT_XORIGIN](https://github.com/glebtsereteli/GMRoomLoader/wiki/Configuration#:~:text=ROOMLOADER_DEFAULT_XORIGIN) config macro.
| `[yorigin=ROOMLOADER_DEFAULT_YORIGIN]` | [Real](https://manual.gamemaker.io/monthly/en/GameMaker_Language/GML_Overview/Data_Types.htm#:~:text=of%20the%20following%3A-,Real%20Numbers,-Boolean) | The y origin to load the room at. <br>**[Optional].** Defaults to the [ROOMLOADER_DEFAULT_YORIGIN](https://github.com/glebtsereteli/GMRoomLoader/wiki/Configuration#:~:text=ROOMLOADER_DEFAULT_YORIGIN) config macro.
| `[scale=1]` | [Real](https://manual.gamemaker.io/monthly/en/GameMaker_Language/GML_Overview/Data_Types.htm#:~:text=of%20the%20following%3A-,Real%20Numbers,-Boolean) | The scale to create the sprite at. <br>**[Optional].** Defaults to 1. |
| `[flags=ROOMLOADER_FLAG.ALL]` | [Enum](https://manual.gamemaker.io/monthly/en/GameMaker_Language/GML_Overview/Variables/Constants.htm#:~:text=get%20an%20error.-,Enums,-An%20enum%20is).[ROOMLOADER_FLAG](https://github.com/glebtsereteli/GMRoomLoader/wiki/Enums#roomloader_flag) | The flags to filter the captured elements by. <br>**[Optional].** Defaults to the [ROOMLOADER_FLAG.ALL](https://github.com/glebtsereteli/GMRoomLoader/wiki/Enums#:~:text=and%20BACKGROUNDS.-,ALL,-Includes%20CORE%20and) flags.
#### Example
```js
// Create event. Take a screenshot of the top-left quadrant of the rm_chunk_easy_01 room with a Middle Center origin, scale it up by x2, and only capture Instances:
screenshot = RoomLoader.take_screenshot_part(rm_chunk_easy_01, 0, 0, 0.5, 0.5, 0.5, 0.5, 2, ROOMLOADER_FLAG.INSTANCES);

// Draw GUI event. Draw screenshot centered on the screen:
if (screenshot != undefined) {
    var _x = display_get_gui_width() / 2;
    var _y = display_get_gui_height() / 2;
    draw_sprite(screenshot, 0, _x, _y);
}
```

---

# 📚 Concepts

## 💢 Origin
All [loading](https://github.com/glebtsereteli/GMRoomLoader/wiki/RoomLoader()-static-constructor-%E2%80%90-main-interface#%E2%84%B9%EF%B8%8F-loading) and [screenshotting](https://github.com/glebtsereteli/GMRoomLoader/wiki/RoomLoader()-static-constructor-%E2%80%90-main-interface#-take_screenshotroom-xorigin-yorigin-flags---idsprite) methods have `[xorigin]` and `[yorigin]` optional arguments that define the origin point for the target room. These parameters are relative, ranging from 0 (no offset) to 1 (full width/height). Any floating-point value between 0 and 1 (inclusive) is valid.
* `xorigin` determines the horizontal origin. 0 aligns to the left, 0.5 to the center, and 1 to the right. Defaults to the [ROOMLOADER_DEFAULT_XORIGIN](https://github.com/glebtsereteli/GMRoomLoader/wiki/Configuration#:~:text=ROOMLOADER_DEFAULT_XORIGIN) config macro.
* `yorigin` determines the vertical origin. 0 aligns to the top, 0.5 to the center, and 1 to the bottom. Defaults to the [ROOMLOADER_DEFAULT_YORIGIN](https://github.com/glebtsereteli/GMRoomLoader/wiki/Configuration#:~:text=ROOMLOADER_DEFAULT_YORIGIN) config macro.

### Examples
```js
// Loads rm_chunk_easy_01 at the bottom right corner of the room:
RoomLoader.load(rm_chunk_easy_01, room_width, room_height, 1, 1);

// Takes a screenshot of rm_level_cliffs with a centered origin:
screenshot = RoomLoader.take_screenshot(rm_level_cliffs, 0.5, 0.5);
```
