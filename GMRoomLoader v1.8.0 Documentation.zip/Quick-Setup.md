While GMRoomLoader provides various tools for handling room data, loading rooms and working with created elements, the following functions are all you need to get it working!

1) [Initialize](https://github.com/glebtsereteli/GMRoomLoader/wiki/RoomLoader()-static-constructor-%E2%80%90-main-interface#-initialization) the data for the room you'd like to load at the start of your game.
```js
RoomLoader.data_init(rm_chunk_easy_01);
```

2) [Load](https://github.com/glebtsereteli/GMRoomLoader/wiki/RoomLoader()-static-constructor-%E2%80%90-main-interface#%E2%84%B9%EF%B8%8F-loading) the room and store the returned instance of [RoomLoaderReturnData](https://github.com/glebtsereteli/GMRoomLoader/wiki/RoomLoaderReturnData()-constructor-%E2%80%90-returned-data-handler) in a variable to clean up later.
```js
room_data = RoomLoader.load(rm_chunk_easy_01, some_x, some_y);
```
3) (Optional) [Clean up](https://github.com/glebtsereteli/GMRoomLoader/wiki/RoomLoaderReturnData()-constructor-%E2%80%90-returned-data-handler#%E2%84%B9%EF%B8%8F-cleanup) the loaded room when needed.
```js
room_data.cleanup();
```

---

That's about it for the basic setup! Check out the [Documentation](https://github.com/glebtsereteli/GMRoomLoader/wiki#documentation) to learn more!